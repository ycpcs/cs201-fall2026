
############################################################
# Assignment specific info
############################################################
set(COURSE_NAME "CS 201")
set(TERM "Fall")
set(PROJECT_NUMBER "lab11")
#set(PROJECT_NAME IntArrayStack)
