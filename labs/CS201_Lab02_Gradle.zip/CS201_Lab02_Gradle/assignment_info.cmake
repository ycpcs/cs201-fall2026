
############################################################
# Assignment specific info
############################################################
set(COURSE_NAME "CS 201")
set(TERM "Fall")
set(PROJECT_NUMBER "lab02")
#set(PROJECT_NAME IntArrayStack)
