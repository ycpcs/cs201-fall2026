public class Student {

    //Fields
    String name;
    int age;
    String username;
    private String password;
    int grade;

    //Constructor
    public Student(String name, int age, String username, String password, int grade){
        this.name = name;
        this.age = age;
        this.username = username;
        this.password = password;
        this.grade = grade;
    }

    //Getter
    public String getPassword(){
        return this.password;
    }

    //Setter
    public void setPassword(String username, String new_password){

        if (new_password.length() > 8 && username == this.username){
            this.password = new_password;
        }else{
            System.out.println("Invalid password or invalid user!!!!");
        }


    }

    //Method
    public String findUsername(String Studentname){
        if (Studentname == this.name){
            return this.username;
        }else{
            System.out.println("Student no found!");
            return "Student not found!";
        }
    }

}
