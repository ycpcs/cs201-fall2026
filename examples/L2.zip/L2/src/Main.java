public class Main {

    public static void main(String[] args){

        Student s1 = new Student("Alice", 18, "alice18", "sdhfu38", 90);


        //System.out.println("The student 1's password is " + s1.password);

        System.out.println("The student 1's password is " + s1.getPassword());

        s1.setPassword("bob","fsdfh23");

        System.out.println("The student 1's new password is " + s1.getPassword());

        Student s2;

        s2 = s1;

        Student s3 = new Student("Alice", 18, "alice18", "sdhfu38", 90);

        if (s1.name == s3.name){
            System.out.println("s1 vs. s3: True");
        }else{
            System.out.println("s1 vs. s3: False");
        }

//        System.out.println("The student 2's grade is " + s1.grade);
//
//        s1.grade = 60;
//
//        System.out.println("The student 2's grade is " + s1.grade);




    }
}
