import java.util.Scanner;

public class Hello {

    public static void main(String[] args){

        System.out.println("Hello World!");

        double num = 45.123;

        System.out.printf("This is a number: %f\n", num);

        //If you want to include a variable for a string, use +, it will
        //automatically convert the integer/double variables to String (same as toString() in C)

        System.out.println("This is a double: " + num + "and this is another number: " + 34);

        Scanner keyboard = new Scanner(System.in);

        System.out.println("What's your name?");

        String name = keyboard.next();  //use .next() method to read a string

        System.out.println("My name is " + name);

        System.out.println("How old are you?");

        int age = keyboard.nextInt(); //use .nextInt() method to read an integer

        System.out.println("I'm " + age + " years old.");

        System.out.println("Enter two integers:");

        int a = keyboard.nextInt();

        int b = keyboard.nextInt();

        int sum = a % b; //same math operators as in C (+, -, *, /, %)

        System.out.println("The sum is " + sum);


    }
}
