import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        // Create list of Integers
        List<Integer> list = new ArrayList<Integer>();
        list.add(8);
        list.add(6);
        list.add(7);
        list.add(7);
        list.add(6);
        list.add(8);
        // Print list
        System.out.println("ArrayList");
        printCollection(list);
        System.out.println("");

        // Create set of Integers
        Set<Integer> set = new TreeSet<Integer>();
        set.addAll(list);
        // Print set
        System.out.println("Set");
        printCollection(set);
        System.out.println("");



        // Remove evens incorrect
//        removeEvens(list);
//        // Print list
//        System.out.println("ArrayList, no evens");
//        printCollection(list);
//        System.out.println("");


    }


    public static<E> void printCollection(Collection<E> coll) {
        Iterator<E> i = coll.iterator();

        while (i.hasNext()) {
            E e = i.next();
            System.out.print(e + " ");
        }
        System.out.println("");
    }

    public static void removeEvens(List<Integer> nums) {
        for (int i = 0; i < nums.size(); i++) {
            if (nums.get(i) % 2 == 0) {
                nums.remove(i);
            }
        }
    }




}