import java.util.ArrayList;

public class ArrayExample {

    public static void main(String[] args){

        ArrayList<String> emailList = new ArrayList<String>();

        emailList.add("Alice123@ycp.edu"); //index 0
        emailList.add("bob9812@ycp.edu"); //index 1
        emailList.add("Cat0924@gmail.com");
        emailList.add("bob9812@ycp.edu");
        emailList.add("bob9812@ycp.edu");

        System.out.println("The size of emailList is " + emailList.size());

        for(int i = 0;i<emailList.size();i++){
            System.out.println(emailList.get(i));
        }

        emailList.set(2, "Cassie123@outlook.com");
        System.out.println("After updating:");

        //emailList.remove("bob9812@ycp.edu");
        ArrayList<String> toRemove = new ArrayList<String>();
        toRemove.add("bob9812@ycp.edu");
        toRemove.add("Alice123@ycp.edu");

        emailList.removeAll(toRemove);

        for(int i = 0;i<emailList.size();i++){
            System.out.println(emailList.get(i));
        }

        //emailList.set(3, "apple@123.com");


//        int[] a = new int[4];
//        System.out.println("The size of array a is " + a.length);
//        a[0] = 34; //index 0
//        a[1] = 1;
//        int[] b;
//        b = a;
//        System.out.println("The first element in b is " + b[0]);
//        a[0] = 121;
//        System.out.println("The first element in b is " + b[0]);



//        for(int i = 0;i<a.length;i++){
//            System.out.println(a[i]);
//        }

//        String[] s = new String[2];
//
//        for(int i = 0;i<s.length;i++){
//            System.out.println(s[i]);
//        }

        //System.out.println(s[2]);




    }
}
