import java.util.Scanner;

public class Main {

    public static void main(String[] args){

        System.out.println("Compute the sum of the integers in the sequence 1...n:");
        System.out.println("Enter your n:");

        Scanner keyboard = new Scanner(System.in);

        int n = keyboard.nextInt();

        System.out.println("Sum of " + n + " integers: " + SumInt.sumInts(n));

    }
}
