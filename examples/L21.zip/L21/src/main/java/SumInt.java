public class SumInt {

//base case: n = 1
//progress: call the method itself with n-1
//termination: n reaches 1
public static int sumInts(int n){
    return sumIntsWorker(n, 1);
}
//worker
public static int sumIntsWorker(int n, int acc){
    
    if(n == 1){
        return acc;
    }
    return sumIntsWorker(n-1, acc + n);
}

}
