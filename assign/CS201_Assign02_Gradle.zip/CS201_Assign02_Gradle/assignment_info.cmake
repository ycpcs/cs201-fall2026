
############################################################
# Assignment specific info
############################################################
set(COURSE_NAME "CS 201")
set(TERM "Fall")
set(PROJECT_NUMBER "assign02_ms1")
#set(PROJECT_NAME IntArrayStack)
